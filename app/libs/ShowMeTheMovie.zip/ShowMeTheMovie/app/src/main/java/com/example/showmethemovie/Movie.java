package com.example.showmethemovie;


public class Movie{


    private String title;
    private float rate;
    private String image_link ;
    private String year;
    private String director;
    private String actor;


    public Movie(String title, float rate, String image_link, String year, String director, String actor){
        this.title = title;
        this.rate = rate;
        this.image_link = image_link;
        this.year = year;
        this.director = director;
        this.actor = actor;
    }

    public String getTitle() {
        return title;
    }

    public String getImage_link() {
        return image_link;
    }

    public float getrate() {
        return rate;
    }
    public String getDirector() {
        return director;
    }
    public String getActor() {
        return actor;
    }
    public String getyear() {
        return year;
    }

}
