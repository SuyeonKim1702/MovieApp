package com.example.showmethemovie;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;


public class MainActivity extends AppCompatActivity {

    private ViewPager viewPager;
    private ViewPagerAdapter pagerAdapter;
    public static Handler mHandler;
    public static String title_list[] = new String[10];
    public static String image_list[] = new String[10];
    Button button;
    Toolbar toolbar;
    NavigationView navigationView;
    private DrawerLayout mDrawerLayout;
    private Context context = this;



    @SuppressLint("HandlerLeak")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // button = findViewById(R.id.bt);
        viewPager = findViewById(R.id.viewpager);
        toolbar =findViewById(R.id.main_toolbar_title);
        navigationView = findViewById(R.id.nav_view);
        mDrawerLayout = findViewById(R.id.drawer_layout);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false); // 제목 안 보이게 하기
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.menu_icon);

        ApiMovie apiMovie = new ApiMovie("20200101", 1); // 사진 요청인지 여부를 여기서 확인 가능.
        Thread apithread = new Thread(apiMovie);
        apithread.start();

        mHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) { //네이버인지 영화진흥원인지
                if (msg.what == 1) { //영화제목 from 영화진흥원
                    //for(int l=0;l<title_list.length;l++)
                    //   System.out.println(title_list[l]+"이다");
                    ApiMovie apiMovie2 = new ApiMovie("20200101", 2); // 사진 요청인지 여부를 여기서 확인 가능.
                    Thread apithread2 = new Thread(apiMovie2);
                    apithread2.start();
                } else { //이미지 from 네이버
                    //
                    if (image_list.length == 10) {
                        for (int l = 0; l < image_list.length; l++)
                            // System.out.println(image_list[l]+"이다");
                            pagerAdapter = new ViewPagerAdapter(MainActivity.this);
                        viewPager.setAdapter(pagerAdapter);
                        viewPager.setPageMargin(-300);
                        viewPager.setHorizontalFadingEdgeEnabled(true);
                        viewPager.setFadingEdgeLength(30);
                        // viewPager.setCurrentItem();
                        // viewPager.notifyDataSetChanged();

                    }

                }

            }

        };

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                menuItem.setChecked(true);
                mDrawerLayout.closeDrawers();

                int id = menuItem.getItemId(); // 선택된 아이템의 id 가져오기
                String title = menuItem.getTitle().toString(); //선택된 아이템의 title(?)

                if(id == R.id.account){
                    Intent intent = new Intent(getApplicationContext(), SearchActivity.class);
                    startActivity(intent);
                }
                else if(id == R.id.setting){
                    Toast.makeText(context, title + ": 설정 정보를 확인합니다.", Toast.LENGTH_SHORT).show();
                }
                else if(id == R.id.logout){
                    Toast.makeText(context, title + ": 로그아웃 시도중", Toast.LENGTH_SHORT).show();
                }

                return true;
            }
        });



        /*
        button.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SearchActivity.class);
                startActivity(intent);
            }
        });   */
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:{ // 왼쪽 상단 버튼 눌렀을 때(햄버거 버튼)
                mDrawerLayout.openDrawer(GravityCompat.START);
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }


}

