package com.example.showmethemovie;


import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;


import java.util.ArrayList;


public class SearchActivity extends AppCompatActivity {
    String keyword;
    EditText et;
    Button bt;
    ListView lv;
    SearchAdapter searchAdapter;
    static Handler vHandler;
    static ArrayList<Movie> movieArrayList = new ArrayList<>();


    @SuppressLint("HandlerLeak")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        et = findViewById(R.id.et_search_keyword);
        bt = findViewById(R.id.bt_search_search);
        lv = findViewById(R.id.lv_search_lv);
        searchAdapter = new SearchAdapter(movieArrayList, SearchActivity.this);
        lv.setAdapter(searchAdapter);

        vHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                if(msg.what == 3){

                   if(msg.arg2 == msg.arg1+1){
                       searchAdapter.notifyDataSetChanged();
                   }
                }

            }

        };





        bt.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
            keyword = et.getText().toString();


                ApiMovie apiMovie = new ApiMovie(keyword,3); // 검색어 타입
                Thread apithread = new Thread(apiMovie);
                 apithread.start();
            }

        });


    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        movieArrayList.removeAll(movieArrayList);
    }
}

